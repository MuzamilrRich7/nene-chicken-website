# NeNe Chicken Carousel: Website Design Brief

- **Design read:** A bold, high-energy local restaurant site for Perth diners and takeaway customers, making crunchy Korean fried chicken feel craveable and easy to order.
- **Concept spine:** The Crunch Journey. The visitor moves through a single cinematic food film from glaze and texture to a full table, then lands on the practical details needed to order or visit.
- **Delivery tier:** spectacle. The requested 3D-style cinematic scroll is expressed through scroll-scrubbed film, layered content, scale, crop and depth. No true WebGL model is included because generation access is not available on this account.
- **Animation mode:** animated-website
- **Journey shape:** single-shot
- **Journey:** 15-second continuous food film: macro crispy chicken and glaze, sesame and scallion detail, platter reveal, then a wider shared table. The scroll position scrubs the video while semantic chapter copy stays accessible above it.
- **World grammar:** glossy tomato red, deep bottle green, ink black and crisp white. Food is photographed like a premium campaign; chapter labels and navigation remain functional, direct and legible.
- **Mobile framing:** dedicated portrait crop/clip, large tap targets, compact nav, cards collapse to one column, reduced-motion mode remains usable with posters and semantic copy.
- **Locked palette:** tomato red #C62836, bottle green #123B2A, ink #141714, white #FFFFFF, muted #B8C0B9. Tomato red is the single accent because it carries the existing restaurant identity while bottle green gives the food imagery a distinct backdrop.
- **Locked type:** Cabinet Grotesk-style display with Inter Tight-style body copy; strong compact headings and clear reading size.
- **Section plan:** 1. Cinematic hero/journey. 2. Menu category gallery. 3. Featured order panel. 4. Local visit details in an asymmetric split. 5. FAQ and ordering help. 6. Footer with conversion actions.
- **Signature components:** layered film frame, diagonal food gallery, large order band, map route panel.
- **Second-read moment:** one macro crop of crispy chicken used as a full-bleed divider before location details.
- **Asset plan:** official NeNe Chicken logo and menu-category images sourced from the supplied official site; scroll film composed from those same brand assets because Higgsfield image/video generation returned an account-plan restriction; matching first-frame posters; portrait version; branded OG card; favicon, touch icon, and web app icons.
- **CTA inventory:** “Order pickup” links to official pickup ordering; “Order delivery” links to official delivery ordering; “View menu” links to the official menu; “Get directions” opens map directions; phone link calls the store.
- **Brand constraints:** Honor existing NeNe Chicken identity and official assets. Do not publish to the Higgsfield community feed. Aim for nenechickencarousel.com, but registration and domain ownership remain with the user.
- **Previous build axes:** no earlier site in this build; choose bold restaurant red + bottle green, grotesk typography, macro food film, journey spine, ticket-like order band, rounded-square corners.
