import { createFileRoute } from "@tanstack/react-router";
import { ScrollScrub } from "@/components/scroll-scrub/scroll-scrub";
import { scrollScrubScenes, scrollScrubTheme } from "@/scroll-scrub-scenes";

const officialMenu = "https://nenechicken.com.au/menu";
const pickupUrl = "https://nenechicken.com.au/pickup";
const deliveryUrl = "https://nenechicken.com.au/delivery";
const directionsUrl = "https://www.google.com/maps/dir/?api=1&destination=NeNe+Chicken+Carousel%2C+1382+Albany+Highway%2C+Cannington+WA+6107";
const phone = "+61862485532";

const menuItems = [
  { name: "Classic Range Chicken", detail: "The Korean fried chicken classic.", image: "/assets/food/classic.png", href: "https://nenechicken.com.au/menu/classic-range-chicken", number: "01" },
  { name: "Wingettes & Drumettes", detail: "Bite-sized favourites with big crunch.", image: "/assets/food/wings.png", href: "https://nenechicken.com.au/menu/wingettes-38-drumettes", number: "02" },
  { name: "Boneless Chicken", detail: "Easy-to-share pieces, full of flavour.", image: "/assets/food/boneless.png", href: "https://nenechicken.com.au/menu/boneless-chicken", number: "03" },
  { name: "Snack Pack", detail: "A quick Korean street-food fix.", image: "/assets/food/snack.png", href: "https://nenechicken.com.au/menu/snack-pack", number: "04" },
  { name: "Lunch Box", detail: "A satisfying option for your lunch break.", image: "/assets/food/lunch.png", href: "https://nenechicken.com.au/menu/lunch-box", number: "05" },
  { name: "Burgers", detail: "Crispy chicken in handheld form.", image: "/assets/food/burger.png", href: "https://nenechicken.com.au/menu/burgers", number: "06" },
  { name: "Drinks", detail: "Pick a drink to go with your meal.", image: "/assets/food/drinks.png", href: "https://nenechicken.com.au/menu/drinks", number: "07" },
  { name: "Wraps", detail: "A fresh take on a crunchy favourite.", image: "/assets/food/wraps.png", href: "https://nenechicken.com.au/menu/wraps", number: "08" },
  { name: "Sides", detail: "Add a little something to the table.", image: "/assets/food/sides.png", href: "https://nenechicken.com.au/menu/sides", number: "09" },
  { name: "K-Dogs", detail: "A Korean street-food favourite.", image: "/assets/food/kdogs.png", href: "https://nenechicken.com.au/menu/k45dogs", number: "10" },
];

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "NeNe Chicken Carousel | Korean Fried Chicken in Cannington" },
      { name: "description", content: "Find NeNe Chicken Carousel in Cannington, Perth for crunchy Korean fried chicken, boneless chicken, wings, burgers, sides and Korean street-food favourites. Order pickup or delivery online." },
      { name: "keywords", content: "NeNe Chicken Carousel, Korean fried chicken Cannington, Korean food Perth, chicken takeaway Cannington, NeNe Chicken menu, order Korean chicken" },
      { property: "og:title", content: "NeNe Chicken Carousel | Korean Fried Chicken" },
      { property: "og:description", content: "Crunchy Korean fried chicken and street-food favourites in Cannington, Perth. View the menu and order online." },
      { property: "og:type", content: "website" },
      { property: "og:image", content: "https://nene-chicken-carousel.higgsfield.app/assets/brand/og-card.jpg" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "canonical", href: "https://nene-chicken-carousel.higgsfield.app/" },
      { rel: "manifest", href: "/assets/brand/site.webmanifest" },
      { rel: "apple-touch-icon", href: "/assets/brand/apple-touch-icon.png" },
    ],
  }),
  component: Index,
});

function Index() {
  const structuredData = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Restaurant",
        "@id": "https://nene-chicken-carousel.higgsfield.app/#restaurant",
        name: "NeNe Chicken Carousel",
        url: "https://nene-chicken-carousel.higgsfield.app/",
        image: "https://nene-chicken-carousel.higgsfield.app/assets/brand/og-card.jpg",
        description: "NeNe Chicken Carousel serves crunchy Korean fried chicken and Korean street-food favourites in Cannington, Perth.",
        servesCuisine: ["Korean", "Korean fried chicken"],
        telephone: "+61 8 6248 5532",
        address: {
          "@type": "PostalAddress",
          streetAddress: "1382 Albany Highway",
          addressLocality: "Cannington",
          addressRegion: "WA",
          postalCode: "6107",
          addressCountry: "AU",
        },
        hasMenu: officialMenu,
      },
      {
        "@type": "WebSite",
        name: "NeNe Chicken Carousel",
        url: "https://nene-chicken-carousel.higgsfield.app/",
        inLanguage: "en-AU",
      },
      {
        "@type": "FAQPage",
        mainEntity: [
          { "@type": "Question", name: "Where is NeNe Chicken Carousel?", acceptedAnswer: { "@type": "Answer", text: "NeNe Chicken Carousel is at 1382 Albany Highway, Cannington WA 6107, in Perth." } },
          { "@type": "Question", name: "Can I order online?", acceptedAnswer: { "@type": "Answer", text: "Use the official NeNe Chicken pickup or delivery pages. Availability depends on the ordering service and your location." } },
          { "@type": "Question", name: "What can I order?", acceptedAnswer: { "@type": "Answer", text: "The official menu includes classic range chicken, wingettes and drumettes, boneless chicken, snack packs, lunch boxes, burgers, wraps, drinks, sides and K-Dogs. Check the live menu for current items." } },
          { "@type": "Question", name: "How do I contact the restaurant?", acceptedAnswer: { "@type": "Answer", text: "Call NeNe Chicken Carousel on (08) 6248 5532. Check the official website for current store hours before visiting." } },
        ],
      },
    ],
  };

  return (
    <main className="nene-site">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }} />
      <header className="site-header">
        <a className="brand-lockup" href="#top" aria-label="NeNe Chicken Carousel home">
          <img src="/assets/brand/logo.png" alt="NeNe Chicken" />
          <span><strong>CAROUSEL</strong><small>CANNINGTON, PERTH</small></span>
        </a>
        <nav className="desktop-nav" aria-label="Main navigation">
          <a href="#menu">Menu</a>
          <a href="#visit">Find us</a>
          <a href="#faq">FAQ</a>
        </nav>
        <a className="header-order" href={pickupUrl} target="_blank" rel="noreferrer">Order online <span aria-hidden="true">↗</span></a>
      </header>

      <section id="top" className="film-section" aria-label="Cinematic Korean fried chicken introduction">
        <div className="film-overline"><span className="red-mark" /> KOREAN FRIED CHICKEN, CANNINGTON</div>
        <ScrollScrub scenes={scrollScrubScenes} theme={scrollScrubTheme} />
        <div className="film-bottomline"><span>CRUNCH FIRST. ASK QUESTIONS LATER.</span><span>NE NE / CAROUSEL</span></div>
      </section>

      <section className="intro-band">
        <p className="intro-label">THE GOOD STUFF</p>
        <h2>Big crunch. Korean soul.</h2>
        <p>NeNe Chicken Carousel serves crunchy marinated Korean fried chicken alongside wings, boneless bites, burgers, sides and Korean street-food favourites. Drop in for a quick bite or bring the whole crew to the table.</p>
        <a className="text-route" href={officialMenu} target="_blank" rel="noreferrer">Explore the full menu <span aria-hidden="true">↗</span></a>
      </section>

      <section id="menu" className="menu-section">
        <div className="section-head">
          <div><p className="section-kicker">PICK YOUR CRUNCH</p><h2>Meet the menu.</h2></div>
          <p>From classic chicken to snack packs and sides, find your next favourite on the official menu.</p>
        </div>
        <div className="menu-grid">
          {menuItems.map((item) => (
            <a className="menu-tile" href={item.href} target="_blank" rel="noreferrer" key={item.name}>
              <div className="menu-photo"><img src={item.image} alt={`${item.name} at NeNe Chicken`} loading="lazy" /><span className="menu-number">{item.number}</span><span className="menu-arrow" aria-hidden="true">↗</span></div>
              <div className="menu-copy"><h3>{item.name}</h3><p>{item.detail}</p></div>
            </a>
          ))}
        </div>
        <div className="menu-endcap"><span>Hungry already?</span><a className="ticket-cta" href={officialMenu} target="_blank" rel="noreferrer">View full menu <span aria-hidden="true">↗</span></a></div>
      </section>

      <section className="order-section">
        <div className="order-image"><img src="/assets/food/snack.png" alt="NeNe Chicken snack pack menu category" loading="lazy" /></div>
        <div className="order-copy">
          <p className="section-kicker">YOUR TABLE, YOUR CALL</p>
          <h2>Bring the crunch home.</h2>
          <p>Planning a night in? Place your order through NeNe Chicken's official ordering pages. Choose pickup when you're on the move or check delivery options for your area.</p>
          <div className="order-actions">
            <a className="pickup-cta" href={pickupUrl} target="_blank" rel="noreferrer">Order pickup <span aria-hidden="true">↗</span></a>
            <a className="delivery-cta" href={deliveryUrl} target="_blank" rel="noreferrer">Order delivery <span aria-hidden="true">↗</span></a>
          </div>
          <small>Ordering availability and delivery coverage are set by the official ordering service.</small>
        </div>
      </section>

      <section id="visit" className="visit-section">
        <div className="visit-title"><p className="section-kicker">COME FIND US</p><h2>Meet us in Carousel.</h2><p>Looking for Korean fried chicken in Cannington? Find NeNe Chicken Carousel on Albany Highway and call ahead if you need help with your order.</p></div>
        <div className="visit-card">
          <span className="visit-index">NNC / 6107</span>
          <div className="visit-address"><h3>NeNe Chicken Carousel</h3><p>1382 Albany Highway<br />Cannington WA 6107, Australia</p></div>
          <div className="visit-contact"><span>PHONE</span><a href={`tel:${phone}`}>(08) 6248 5532</a><span>MENU & ORDERING</span><a href={officialMenu} target="_blank" rel="noreferrer">Official NeNe Chicken website ↗</a></div>
          <a className="directions-cta" href={directionsUrl} target="_blank" rel="noreferrer"><span>Get directions</span><span aria-hidden="true">↗</span></a>
        </div>
      </section>

      <section id="faq" className="faq-section">
        <div className="faq-heading"><p className="section-kicker">GOOD TO KNOW</p><h2>Before you dig in.</h2></div>
        <div className="faq-list">
          <details><summary>Where is NeNe Chicken Carousel?</summary><p>You'll find the restaurant at 1382 Albany Highway, Cannington WA 6107, in Perth. Use the directions link above for a route from your current location.</p></details>
          <details><summary>Can I order online?</summary><p>Yes. Use the official NeNe Chicken pickup or delivery pages linked on this website. Availability depends on the ordering service and your location.</p></details>
          <details><summary>What can I order?</summary><p>The official menu includes classic range chicken, wingettes and drumettes, boneless chicken, snack packs, lunch boxes, burgers, wraps, drinks, sides and K-Dogs. Menu items can change, so check the live menu for the current selection.</p></details>
          <details><summary>How do I contact the restaurant?</summary><p>Call NeNe Chicken Carousel on (08) 6248 5532. For the most up-to-date store hours, check the official NeNe Chicken website before visiting.</p></details>
        </div>
      </section>

      <footer className="site-footer">
        <div className="footer-brand"><img src="/assets/brand/logo.png" alt="NeNe Chicken" /><p>Korean fried chicken and street-food favourites in Cannington, Perth.</p></div>
        <div className="footer-links"><a href={officialMenu} target="_blank" rel="noreferrer">Menu ↗</a><a href={pickupUrl} target="_blank" rel="noreferrer">Pickup ↗</a><a href={deliveryUrl} target="_blank" rel="noreferrer">Delivery ↗</a><a href={directionsUrl} target="_blank" rel="noreferrer">Directions ↗</a></div>
        <div className="footer-bottom"><span>© {new Date().getFullYear()} NeNe Chicken Carousel</span><span>1382 Albany Highway, Cannington WA 6107</span></div>
      </footer>
    </main>
  );
}
