/** Scroll-scrub chapter data for NeNe Chicken Carousel. */
import type { ScrollScrubScene, ScrollScrubTheme } from "@/components/scroll-scrub/scroll-scrub";

export const scrollScrubTheme: ScrollScrubTheme = {
  accent: "#C62836",
  background: "#141714",
  ink: "#FFFFFF",
  muted: "#D0D7D1",
};

export const scrollScrubScenes: ScrollScrubScene[] = [
  {
    body: "NeNe Chicken Carousel brings crunchy Korean fried chicken and Korean street-food favourites to Cannington, Perth.",
    clip: "/assets/world/scene-01.mp4",
    id: "crunch-journey",
    kicker: "KOREAN FRIED CHICKEN · CANNINGTON",
    label: "The crunch",
    mobileClip: "/assets/world/scene-01-mobile.mp4",
    mobilePoster: "/assets/world/scene-01-mobile-poster.jpg",
    poster: "/assets/world/scene-01-poster.jpg",
    tags: ["Crispy chicken", "Korean flavour", "Made to share"],
    title: "Hear the crunch. Taste Korea.",
    align: "left",
    scroll: 2.1,
    linger: 0.12,
    objectPosition: "50% 50%",
    mobileObjectPosition: "50% 50%",
  },
];
